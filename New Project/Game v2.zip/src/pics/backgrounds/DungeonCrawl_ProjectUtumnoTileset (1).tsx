<?xml version="1.0" encoding="UTF-8"?>
<tileset name="DungeonCrawl_ProjectUtumnoTileset (1)" tilewidth="32" tileheight="32">
 <image source="../../../../../../../../Downloads/Sprites/DungeonCrawl_ProjectUtumnoTileset (1).png" trans="ff0000" width="2048" height="1536"/>
</tileset>
